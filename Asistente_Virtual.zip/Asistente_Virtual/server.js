const express = require('express');
const axios = require('axios');
const cors = require('cors');  // Agregar cors

const app = express();
const port = 3000;

// Habilitar CORS para todas las rutas
app.use(cors());  // Añadir cors a todas las rutas

app.use(express.json());

// Ruta para manejar las solicitudes desde el frontend
app.post('/api/chat', async (req, res) => {
  const { question } = req.body;

  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: question }]
    }, {
      headers: {
        'Authorization': `Bearer sk-WcPdYBy8qXQQEtt6LZ6x-Am_SL9hDU0n4u2L382jB5T3BlbkFJHc1onhWyyjpxqEpkutwinoeeyG5adueFqN_HTr2LsA`,  
        'Content-Type': 'application/json'
      }
    });

    res.json(response.data);  // Enviar la respuesta de OpenAI al frontend
  } catch (error) {
    console.error('Error al llamar a la API de OpenAI:', error.message);
    res.status(500).json({ message: "Error al conectarse con OpenAI", error: error.message });
  }
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor proxy escuchando en el puerto ${port}`);
});
